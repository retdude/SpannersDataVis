
/*(async () => {
    const fs = require("fs");
    const { parse } = require("csv-parse");
    const {execute} = deployments
    const { deployer } = await getNamedAccounts()
    await execute('ExordiumOne', {from: deployer}, 'toggleActive')
  })();
  
*/

var nodes = {};
var edges = [];

const node= {
    //fill with attributes
    number: 0,
    x: 0,
    y: 0,
    edges: {},

    applyAttributes: function(){
        this.x = Math.random() * 580; //these values so that thhe coodinates
        this.y = Math.random() * 420;//fit inside the SVG normally
        this.edges ={};

        return;
    
    }

    
}
fs.createReadStream("graph_n30_p.7.csv")
.pipe(parse({ delimiter: ",", from_line: 2 }))
  .on("data", function (row) {
    //console.log(row);
    edges.push(row);
  })
  .on("error", function (error) {
    console.log(error.message);
  })
  .on("end", function () {
    console.log(edges);
  });
console.log(edges);